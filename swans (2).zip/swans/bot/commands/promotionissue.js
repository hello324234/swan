const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Promotion = require('../utils/promotionSchema');


module.exports = {
  data: new SlashCommandBuilder()
    .setName('promotion-issue')
    .setDescription('Promote a staff member!')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user being promoted')
        .setRequired(true)
    )
    .addRoleOption(option =>
      option.setName('rank')
        .setDescription('Select the rank for the promotion')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the promotion')
        .setRequired(true)
    ),



  async execute(interaction) {
    await interaction.deferReply({ flags: 64 });
    try {
      const promotionChannel = interaction.guild.channels.cache.get('1447343152280109086');
      if (!promotionChannel) return interaction.editReply({ content: 'Could not find **promotion** channel.', flags: 64 });

      const targetUser = interaction.options.getUser('user');
      if (targetUser.id === interaction.user.id) return interaction.editReply({ content: 'You cannot **promote** yourself.', flags: 64 });

      const newRank = interaction.options.getRole('rank');
      const handler = interaction.user;

      const reason = interaction.options.getString('reason');

      const authorMember = await interaction.guild.members.fetch(handler.id);
      const requiredRole = '1447342830229127230';
      if (!authorMember.roles.cache.has(requiredRole)) {
        return interaction.editReply({ content: 'You do not have **permission** to use this command.', flags: 64 });
      }

      const generatePromotionId = () => {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        return Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
      };
      const promotionId = generatePromotionId();

      const newPromotion = new Promotion({
        userId: targetUser.id,
        rank: newRank.name,
        moderatorId: handler.id,
        promotionId
      });

      await newPromotion.save();

      const embed = new EmbedBuilder()
        .setTitle('Promotion')
        .setDescription('The HR team has decided to issue you a promotion, read below for more details.')
       .addFields(
  { name: '**Username**', value: `${targetUser}`, inline: true },
  { name: '**New Rank**', value: `${newRank}`, inline: true },
  { name: '**Reason**', value: reason, inline: false }
)

        .setFooter({ text: `Handler: ${handler.username} • Promotion ID: ${promotionId}`, iconURL: handler.displayAvatarURL({ dynamic: true }) })
        .setColor('#242429');

      await promotionChannel.send({ content: `${targetUser}`, embeds: [embed] });

      await interaction.editReply({ content: `<@${targetUser.id}> has been promoted to ${newRank}.`, flags: 64 });

    } catch (error) {
      console.error(' Promotion Issue command error:', error);

      const errorReply = {
        content: 'An **error** occurred, try again later.',
        flags: 64
      };

      try {
        if (interaction.deferred || interaction.replied) {
          await interaction.followUp(errorReply);
        } else {
          await interaction.reply(errorReply);
        }
      } catch (e) {
        console.error(' Promotion Issue command error:', e);
      }
    }
  }
};