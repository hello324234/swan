const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'tax',         
  description: 'Calculate price to receive a specific Robux amount after tax.',
  execute: async (message, args) => {
    const requiredRoleId = '1447342842610454582'; 

    if (!message.member.roles.cache.has(requiredRoleId)) {
      return message.reply('You do not have permission to use this command.');
    }

    const amount = parseInt(args[0], 10);
    if (isNaN(amount) || amount <= 0) {
      return message.reply('Please provide a valid Robux amount. Example: `!tax 100`');
    }

    const taxed = Math.round(amount / 0.7);

    const embed = new EmbedBuilder()
      .setColor('#242429')
      .setDescription(
        `**Amount Entered:** ${amount} Robux\n` +
        `**Amount Needed:** ${taxed} Robux`
      )
      .setFooter({ text: 'Roblox takes a 30% marketplace tax.' });

    await message.reply({ embeds: [embed] });
  },
};
