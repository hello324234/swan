const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');
const path = require('path');
const Infraction = require(path.join(__dirname, '..', 'utils', 'infractionSchema'));


module.exports = {
  data: new SlashCommandBuilder()
    .setName('infraction-view')
    .setDescription('View a staff member\'s infractions')
    .addUserOption(option => 
      option.setName('user')
        .setDescription('The user to view infractions for')
        .setRequired(true)
    ),

  async execute(interaction) {
    await interaction.deferReply({ flags: 64 });

    try {
      const user = interaction.options.getUser('user');
      const authorMember = await interaction.guild.members.fetch(interaction.user.id);
      const requiredRole = '1447342830229127230';

      if (!authorMember.roles.cache.has(requiredRole)) {
        return interaction.editReply({
          content: 'You do not have **permission** to use this command.'
        });
      }

      const infractions = await Infraction.find({ userId: user.id });
      if (!infractions.length) {
        return interaction.editReply({
          content: '**No infractions** found for this **user**.'
        });
      }

      const infractionEmbed = new EmbedBuilder()
        .setTitle(`Infractions for ${user.username}`)
        .setColor('#242429');

      infractions.forEach(infraction => {
        const timestamp = `<t:${Math.floor(new Date(infraction.date).getTime() / 1000)}:f>`;
        const punishment = infraction.punishment || 'Not specified';
        const reason = infraction.reason || 'No reason provided';
        infractionEmbed.addFields({
          name: `Infraction ID: ${infraction.infractionId}`,
          value: `**By:** <@${infraction.moderatorId}>\n**Punishment:** ${punishment}\n**Reason:** ${reason}\n**Time:** ${timestamp}`,
          inline: false
        });
      });

      await interaction.editReply({ embeds: [infractionEmbed] });

    } catch (error) {
      console.error('❌ Infraction View command error:', error);

      const errorReply = {
        content: 'An **error** occurred, try again later.',
        flags: 64
      };

      try {
        if (interaction.deferred || interaction.replied) {
          await interaction.followUp(errorReply);
        } else {
          await interaction.reply(errorReply);
        }
      } catch (e) {
        console.error('❌ Infraction View command error:', e);
      }
    }
  }
};