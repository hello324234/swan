const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');
const path = require('path');
const Infraction = require(path.join(__dirname, '..', 'utils', 'infractionSchema'));
const mongoose = require('mongoose');




const infractionSchema = new mongoose.Schema({
    userId: String,
    reason: String,
    punishment: String,
    date: { type: Date, default: Date.now }, 
    moderatorId: String,
    infractionId: String,
});

module.exports = mongoose.model('Infraction', infractionSchema);