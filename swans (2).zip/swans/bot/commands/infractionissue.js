const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');
const path = require('path');
const Infraction = require(path.join(__dirname, '..', 'utils', 'infractionSchema'));


module.exports = {
  data: new SlashCommandBuilder()
    .setName('infraction-issue')
    .setDescription('Infract a staff member!')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user being infracted.')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('punishment')
        .setDescription('Choose a punishment.')
        .setRequired(true)
        .addChoices(
          { name: 'Termination', value: 'Termination' },
          { name: 'Demotion', value: 'Demotion' },
          { name: 'Suspension', value: 'Suspension' },
          { name: 'Staff Blacklist', value: 'Staff Blacklist' },
          { name: 'Strike', value: 'Strike' },
          { name: 'Warning', value: 'Warning' },
          { name: 'Verbal Warning', value: 'Verbal Warning' },
          { name: 'Notice', value: 'Notice' }
        )
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the infraction')
        .setRequired(true)
    ),

  async execute(interaction) {
    await interaction.deferReply({ flags: 64 });
    try {
      const infractionChannel = interaction.guild.channels.cache.get('1447343152280109086');
      if (!infractionChannel) return interaction.editReply({ content: 'Could not find **infraction** channel.', flags: 64 });

      const targetUser = interaction.options.getUser('user');
      if (targetUser.id === interaction.user.id) return interaction.editReply({ content: 'You cannot **infract** yourself.', flags: 64 });

      const punishment = interaction.options.getString('punishment');
      const reason = interaction.options.getString('reason');
      const handler = interaction.user;

      const authorMember = await interaction.guild.members.fetch(handler.id);
      const requiredRole = '1447342830229127230';
      if (!authorMember.roles.cache.has(requiredRole)) {
        return interaction.editReply({ content: 'You do not have **permission** to use this command.', flags: 64 });
      }

      const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
      if (!member || !member.roles.cache.has('1447342834939334698')) return interaction.editReply({ content: 'User is not a **staff member**.', flags: 64 });

      const generateInfractionId = () => {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        return Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
      };
      const infractionId = generateInfractionId();

      const newInfraction = new Infraction({ userId: targetUser.id, punishment, reason, moderatorId: handler.id, infractionId });
      await newInfraction.save();

      const embed = new EmbedBuilder()
        .setTitle('Infraction')
        .setDescription('The HR team has decided to issue you an infraction, read below for more details.')
        .addFields(
          { name: '**Username**', value: `${targetUser}`, inline: true },
          { name: '**Punishment**', value: punishment, inline: true },
          { name: '**Reason**', value: reason }
        )
        .setFooter({ text: `Handler: ${handler.username} • Infraction ID: ${infractionId}`, iconURL: handler.displayAvatarURL({ dynamic: true }) })
        .setColor('#242429');

      const message = await infractionChannel.send({ content: `${targetUser}`, embeds: [embed] });

      const thread = await message.startThread({ name: 'Discussion', autoArchiveDuration: 1440, type: ChannelType.PublicThread });
      await thread.send('You can upload proof or discuss here.');

      await interaction.editReply({ content: `<@${targetUser.id}> has been infracted with the following punishment; **${punishment}**.`, flags: 64 });

    } catch (error) {
      console.error('❌ Infraction Issue command error:', error);

      const errorReply = {
        content: 'An **error** occurred, try again later.',
        flags: 64
      };

      try {
        if (interaction.deferred || interaction.replied) {
          await interaction.followUp(errorReply);
        } else {
          await interaction.reply(errorReply);
        }
      } catch (e) {
        console.error('❌ Infraction Issue command error:', e);
      }
    }
  }
};