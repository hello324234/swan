const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Promotion = require('../utils/promotionSchema');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('promotion-view')
    .setDescription("View a staff member's promotions")
    .addUserOption(option => 
      option.setName('user')
        .setDescription('The user to view promotions for')
        .setRequired(true)
    ),

  async execute(interaction) {
    await interaction.deferReply({ flags: 64 });

    try {
      const user = interaction.options.getUser('user');
      const authorMember = await interaction.guild.members.fetch(interaction.user.id);
      const requiredRole = '1447342830229127230';

      if (!authorMember.roles.cache.has(requiredRole)) {
        return interaction.editReply({
          content: 'You do not have **permission** to use this command.'
        });
      }

      const promotions = await Promotion.find({ userId: user.id });
      if (!promotions.length) {
        return interaction.editReply({
          content: '**No promotions** found for this **user**.'
        });
      }

      const promotionEmbed = new EmbedBuilder()
        .setTitle(`Promotions for ${user.username}`)
        .setColor('#242429');

    
      const fields = promotions.map(promo => {
        const timestamp = `<t:${Math.floor(new Date(promo.date).getTime() / 1000)}:f>`;
        const rank = promo.rank || 'Not specified';
        
        return [
          {
            name: `Promotion ID: ${promo.promotionId || 'N/A'}`,
            value: `**By:** <@${promo.moderatorId || 'Unknown'}>\n**New Rank:** ${rank}\n**Time:** ${timestamp}`,
            inline: false
          },
          {
            name: 'Reason',
            value: promo.reason || 'No reason provided',
            inline: false
          }
        ];
      }).flat();

      promotionEmbed.addFields(fields);

      await interaction.editReply({ embeds: [promotionEmbed] });

    } catch (error) {
      console.error(' Promotion View command error:', error);

      const errorReply = {
        content: 'An **error** occurred, try again later.',
        flags: 64
      };

      try {
        if (interaction.deferred || interaction.replied) {
          await interaction.followUp(errorReply);
        } else {
          await interaction.reply(errorReply);
        }
      } catch (e) {
        console.error(' Promotion View command error:', e);
      }
    }
  }
};
