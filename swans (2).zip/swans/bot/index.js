const {
  Events,
  ActivityType,
  Client,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
} = require('discord.js');
const mongoose = require('mongoose');

const client = new Client({
  intents: [
    'Guilds',
    'GuildMembers',
    'GuildMessages',
    'GuildPresences',
    'DirectMessages',
    'MessageContent',
  ],
});

client.config = require('./config.json');
client.cooldowns = new Map();
client.cache = new Map();
client.messages = new Map();
client.commands = new Map();
client.buttons = new Map();
client.dropdowns = new Map();
client.modals = new Map();
client.welcomeMessages = new Map();

(async () => {
  try {
    if (!client.config.mongoURL) {
      throw new Error('mongoURL is missing in config.json');
    }

    await mongoose.connect(client.config.mongoURL, {
      serverSelectionTimeoutMS: 30000,
    });

    console.log(' MongoDB connected successfully');

    require('./utils/ComponentLoader.js')(client);
    require('./utils/EventLoader.js')(client);
    require('./utils/RegisterCommands.js')(client);

    await client.login(client.config.TOKEN);
  } catch (err) {
    console.error(' Failed to start bot:', err);
    process.exit(1);
  }
})();

client.once(Events.ClientReady, () => {
  console.log(` Logged in as ${client.user.tag}`);

  let index = 0;

  setInterval(() => {
    const totalMembers = client.guilds.cache.reduce(
      (acc, guild) => acc + guild.memberCount,
      0
    );

    const activities = [
      { name: "Overseeing Swan's Lake operations", type: ActivityType.Watching },
      { name: `Watching ${totalMembers} members`, type: ActivityType.Watching },
      { name: "Helping customers with their 🎨 orders", type: ActivityType.Playing },
    ];

    const activity = activities[index];
    client.user.setActivity(activity.name, { type: activity.type });
    index = (index + 1) % activities.length;
  }, 10000);
});

client.on(Events.GuildMemberAdd, async (member) => {
  const WELCOME_CHANNEL_ID = '1447343064736727111';
  const channel = member.guild.channels.cache.get(WELCOME_CHANNEL_ID);
  if (!channel) return;

  const content = `Welcome to  **${member.guild.name}** <@${member.id}>! Where **elegance** meets **design**`;

  const memberCountBtn = new ButtonBuilder()
    .setCustomId('membercount')
    .setLabel(`${member.guild.memberCount}`)
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(true);

  const dashboardBtn = new ButtonBuilder()
    .setLabel('Information')
    .setStyle(ButtonStyle.Link)
    .setEmoji('<:swan_person:1448093716613955767>')
    .setURL('https://discord.com/channels/1447342580227510413/1447343015915159654');

  const row = new ActionRowBuilder().addComponents(memberCountBtn, dashboardBtn);

  try {
    const existingMessageId = client.welcomeMessages.get(member.guild.id);
    let welcomeMessage;

    if (existingMessageId) {
      try {
        welcomeMessage = await channel.messages.fetch(existingMessageId);
      } catch {
        welcomeMessage = await channel.send({ content, components: [row] });
        client.welcomeMessages.set(member.guild.id, welcomeMessage.id);
      }
    } else {
      welcomeMessage = await channel.send({ content, components: [row] });
      client.welcomeMessages.set(member.guild.id, welcomeMessage.id);
    }

    memberCountBtn.setLabel(`${member.guild.memberCount}`);
    await welcomeMessage.edit({
      components: [new ActionRowBuilder().addComponents(memberCountBtn, dashboardBtn)],
    });
  } catch (err) {
    console.error('Failed to send or update welcome message:', err);
  }
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const prefix = client.config.prefix;
  if (!prefix || !message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();
  const command = client.messages.get(commandName);
  if (!command) return;

  try {
    await command.execute(message, args, client);
  } catch (error) {
    console.error(error);
    await message.reply(
      `There was an error running this command:\n\`\`\`${error.message || error}\`\`\``
    );
  }
});

async function InteractionHandler(interaction, type) {
  const component = client[type]?.get(
    interaction.customId ?? interaction.commandName
  );
  if (!component) return;

  try {
    await component.execute(interaction, client);
  } catch (error) {
    console.error(error);

    try {
      if (!interaction.deferred && !interaction.replied) {
        await interaction.deferReply({ ephemeral: true });
      }

      await interaction.editReply({
        content: ' There was an error while executing this command.',
        embeds: [],
        components: [],
      });
    } catch {}
  }
}

client.on('interactionCreate', async (interaction) => {
  if (interaction.isChatInputCommand())
    return InteractionHandler(interaction, 'commands');

  if (interaction.isButton())
    return InteractionHandler(interaction, 'buttons');

  if (interaction.isStringSelectMenu())
    return InteractionHandler(interaction, 'dropdowns');

  if (interaction.isModalSubmit())
    return InteractionHandler(interaction, 'modals');
});
