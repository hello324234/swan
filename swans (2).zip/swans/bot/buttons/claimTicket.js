const {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
} = require('discord.js');
const Ticket = require('../utils/ticketSchema');

module.exports = {
  customID: 'claimTicket',

  async execute(interaction) {
    const requiredRoleId = "roleid";
    
    if (!interaction.member.roles.cache.has(requiredRoleId)) {
        return interaction.reply({
          content: `You don't have permission to use this button.`,
          ephemeral: true
      });
    } 

    try {
      const user = interaction.user;
      const channel = interaction.channel;

      const ticket = await Ticket.findOneAndUpdate(
        { channelId: channel.id },
        { claimedBy: user.id },
        { claimStatus: 'claimed' },
      );

      if (!ticket) {
        return await interaction.reply({
          content: 'Ticket not found in the database.',
          ephemeral: true,
        });
      }

      const embed = new EmbedBuilder()
        .setDescription(`This ticket has been claimed by <@${user.id}>.`)
        .setColor('#242429');

      const unclaimButton = new ButtonBuilder()
        .setCustomId('unclaimTicket')
        .setLabel('Unclaim')
        .setStyle(ButtonStyle.Secondary);

      const closeButton = new ButtonBuilder()
        .setCustomId('closeTicket')
        .setLabel('Close')
        .setStyle(ButtonStyle.Danger);

      const row = new ActionRowBuilder().addComponents(
        unclaimButton,
        closeButton,
      );

      await interaction.update({
        components: [row],
      });

      await channel.send({ embeds: [embed] });

    } catch (error) {
      console.error('Error claiming ticket:', error);
      if (!interaction.replied) {
        await interaction.reply({
          content: 'An error occurred while claiming the ticket.',
          ephemeral: true,
        });
      }
    }
  },
};
