const { ButtonStyle, ActionRowBuilder, ButtonBuilder } = require('discord.js');
module.exports = {
customID: 'paid',
async execute(interaction) {

try {
    await interaction.deferUpdate();
} catch (error) {
    console.error('Failed to defer interaction:', error);
    return;
}

try {
const requiredRoleId = '1447342829629346034'; 
if (!interaction.member.roles.cache.has(requiredRoleId)) {
return await interaction.followUp({
content: ' You do not have permission to use this button.',
ephemeral: true
                });
            }
const originalEmbed = interaction.message.embeds[0];
if (!originalEmbed) {
return await interaction.followUp({ 
content: " Original embed not found.", 
ephemeral: true 
                });
            }
const button = new ButtonBuilder()
                .setCustomId('paid')
                .setLabel('Paid')
                .setStyle(ButtonStyle.Success)
                .setDisabled(true);
const disabledRow = new ActionRowBuilder().addComponents(button);
await interaction.editReply({
components: [disabledRow],
            });
        } catch (error) {
console.error('Error in paid button:', error);
        }
    }
};