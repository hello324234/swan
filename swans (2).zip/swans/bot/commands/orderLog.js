const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('order-log')
        .setDescription('Log an order with customer, product, and price details.')
        .addUserOption(option =>
            option.setName('customer')
                .setDescription('The customer making the order.')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('product')
                .setDescription('Product being ordered.')
                .setRequired(true)
                .addChoices(
                    { name: 'Liveries', value: 'Liveries' },
                    { name: 'Clothing', value: 'Clothing' },
                    { name: 'Graphics', value: 'Graphics' },
                ))
        .addNumberOption(option =>
            option.setName('price')
                .setDescription('Price of the product **WITHOUT** tax.')
                .setRequired(true)),

    async execute(interaction) {
        const requiredRoleId = '1447342834939334698';

        if (!interaction.member.roles.cache.has(requiredRoleId)) {
            return interaction.reply({
                content: 'You do not have permission to use this command.',
            });
        }

        try {
            const customer = interaction.options.getUser('customer');
            const product = interaction.options.getString('product');
            const price = interaction.options.getNumber('price');

            const channel = await interaction.guild.channels.fetch('1447343152280109086');
            if (!channel) {
                return await interaction.reply({ content: 'Could not find the order log channel.', ephemeral: true });
            }

            if (isNaN(price) || price <= 0) {
                return await interaction.reply({ content: 'Please enter a valid, positive price.', ephemeral: true });
            }

            const robloxTaxRate = 0.3;
            const fullPrice = Math.round(price / (1 - robloxTaxRate));
            const designerEarnings = Math.round(price * 0.7);

            const embed = new EmbedBuilder()
                .setColor("#242429")
                .setTitle(`New Order Logged`)
                .setAuthor({
                    name: interaction.user.tag,
                    iconURL: interaction.user.displayAvatarURL(),
                })
                .addFields(
                    { name: 'Customer:', value: `<@${customer.id}>`, inline: false },
                    { name: 'Designer:', value: `<@${interaction.user.id}>`, inline: false },
                    { name: 'Product:', value: product, inline: false },
                    { name: 'Full Price (including tax):', value: `${fullPrice}`, inline: false },
                    { name: 'Designer Earnings:', value: `${designerEarnings}`, inline: false },
                )
                .setImage('https://media.discordapp.net/attachments/1447379730352308306/1447387615652352080/image.png?ex=69400202&is=693eb082&hm=3dba0eac4e7413db0e980a2331a4f46c950f3d410f265104e80e1bf28dfdc9cc&=&format=webp&quality=lossless&width=2288&height=86')

            const paidButton = new ButtonBuilder()
                .setCustomId('paid')
                .setLabel('Mark Paid')
                .setStyle(ButtonStyle.Secondary);

            const row = new ActionRowBuilder().addComponents(paidButton);

            await channel.send({
                embeds: [embed],
                components: [row]
            });

            await interaction.reply({ content: `Your order has been logged successfully.`, ephemeral: true });

        } catch (error) {
            console.error('Error executing command:', error);

            try {
                await interaction.reply({
                    content: 'There was an error logging the order. Please try again later.',
                    ephemeral: true
                });
            } catch (e) {
                console.error('Error sending failure message:', e);
            }
        }

        
    }
};



