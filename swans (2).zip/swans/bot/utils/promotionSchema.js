const mongoose = require('mongoose');

const promotionSchema = new mongoose.Schema({
    userId: String,
    rank: String,
    date: { type: Date, default: Date.now },
    moderatorId: String,
    promotionId: String,
});

module.exports = mongoose.model('Promotion', promotionSchema);
