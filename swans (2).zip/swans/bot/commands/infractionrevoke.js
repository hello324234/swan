const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');
const path = require('path');
const Infraction = require(path.join(__dirname, '..', 'utils', 'infractionSchema'));

module.exports = {
  data: new SlashCommandBuilder()
    .setName('infraction-revoke')
    .setDescription('Void an infraction by its ID')
    .addStringOption(option =>
      option.setName('id')
        .setDescription('The infraction ID')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the revoke')
        .setRequired(true)
    ),

  async execute(interaction) {
    try {
      const infractionId = interaction.options.getString('id');
      const reason = interaction.options.getString('reason');
      const handler = interaction.user;

      const authorMember = await interaction.guild.members.fetch(handler.id);
      const requiredRole = '1447342830229127230';

      if (!authorMember.roles.cache.has(requiredRole)) {
        return interaction.reply({ content: 'You do not have **permission** to use this command.', flags: 64 });
      }

      const infraction = await Infraction.findOne({ infractionId });
      if (!infraction) {
        return interaction.reply({ content: 'Could not find an **infraction** with that ID.', flags: 64 });
      }

      if (infraction.userId === handler.id) {
        return interaction.reply({ content: 'You cannot **revoke** your infraction.', flags: 64 });
      }

      const infractionChannel = interaction.guild.channels.cache.get('1447343152280109086');
      if (infractionChannel) {
        const messages = await infractionChannel.messages.fetch({ limit: 100 });
        const message = messages.find(msg => msg.embeds.length > 0 && msg.embeds[0].footer?.text.includes(infractionId));

        if (message) {
          const embed = message.embeds[0];
          let newFooterText = embed.footer.text;
          if (!newFooterText.includes('• Revoked')) {
            newFooterText += ' • Revoked';
          }

          const updatedEmbed = EmbedBuilder.from(embed).setFooter({ text: newFooterText, iconURL: embed.footer.iconURL });
          await message.edit({ embeds: [updatedEmbed] });

          await message.reply({
            content: `Infraction for <@${infraction.userId}> has been revoked by <@${handler.id}>, reason; **${reason}**`
          });
        }
      }

      await Infraction.deleteOne({ infractionId });

      return interaction.reply({ content: `**Successfully** revoked <@${infraction.userId}>'s infraction.`, flags: 64 });

    } catch (error) {
      console.error(' Infraction Revoke command error:', error);

      const errorReply = {
        content: 'An **error** occurred, try again later.',
        flags: 64
      };

      try {
        if (interaction.deferred || interaction.replied) {
          await interaction.followUp(errorReply);
        } else {
          await interaction.reply(errorReply);
        }
      } catch (e) {
        console.error(' Infraction Revoke command error:', e);
      }
    }
  }
};