const {
  AttachmentBuilder,
  EmbedBuilder,
} = require('discord.js');
const DiscordTranscripts = require('discord-html-transcripts');
const Ticket = require('../utils/ticketSchema');

const LOG_CHANNEL_ID = 'logchannel';

module.exports = {
  customID: 'closeTicket',

  async execute(interaction) {
    const requiredRoleId = "roleid";
  
    if (!interaction.member.roles.cache.has(requiredRoleId)) {
      return interaction.reply({
        content: `You don't have permission to use this button.`,
        ephemeral: true
      });
    }

    const channel = interaction.channel;
    const closer = interaction.user;

    try {
      await interaction.reply({
        content: 'This ticket is being closed.',
        ephemeral: false,
      });

      const ticket = await Ticket.findOne({ channelId: channel.id });
      if (!ticket) {
        return interaction.editReply({ content: 'Ticket not found in database.', ephemeral: true });
      }

      const closureReason = ticket.closeReason || 'No reason provided.';

      await Ticket.findOneAndUpdate(
        { channelId: channel.id },
        {
          status: 'closed',
          closedBy: closer.id,
          closeReason: closureReason,
        }
      );

      const transcript = await DiscordTranscripts.createTranscript(channel, {
        limit: -1,
        returnType: 'buffer',
        filename: `${ticket.username}-${ticket.ticketId}.html`,
        saveImages: true
      });

      const transcriptFile = new AttachmentBuilder(transcript, {
        name: `${ticket.username}-${ticket.ticketId}.html`,
      });

      const dmEmbed = new EmbedBuilder()
        .setTitle('Ticket Closure')
        .setColor('#242429')
        .setDescription(`Your ticket has been closed.`)
        .addFields(
          { name: 'Closure Reason', value: closureReason, inline: true },
          { name: 'Closed By', value: `<@${closer.id}>`, inline: true }
        )
        .setFooter({ text: `Ticket ID: ${ticket.ticketId}` })
        .setTimestamp();

      const logEmbed = new EmbedBuilder()
        .setTitle('Ticket Closure')
        .setColor('#242429')
        .addFields(
          { name: 'Closure Reason', value: closureReason, inline: true },
          { name: 'Closed By', value: `<@${closer.id}>`, inline: true }
        )
        .setFooter({ text: `User ID: ${ticket.userId} | Ticket ID: ${ticket.ticketId}` })
        .setTimestamp();

      const logChannel = await interaction.client.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
      if (logChannel && logChannel.isTextBased()) {
        await logChannel.send({
          embeds: [logEmbed],
          files: [transcriptFile]
        }).catch(err => console.error('Error sending to log channel:', err));
      }

      const user = await interaction.client.users.fetch(ticket.userId).catch(() => null);
      if (user) {
        await user.send({
          embeds: [dmEmbed],
        }).catch(() => {
          console.warn(`Could not DM user ${ticket.userId}. DMs are likely disabled.`);
          interaction.followUp({
            content: 'User DMs are disabled — they were not notified.',
            ephemeral: true
          }).catch(() => {});
        });
      } else {
        interaction.followUp({
          content: 'Unable to find the user to DM.',
          ephemeral: true
        }).catch(() => {});
      }

      setTimeout(async () => {
        await channel.delete().catch(err => console.error('Error deleting channel:', err));
      }, 3000);

    } catch (error) {
      console.error('Error closing ticket:', error);
      try {
        await interaction.reply({ content: 'Failed to close the ticket.', ephemeral: true });
      } catch {}
    }
  }
};
