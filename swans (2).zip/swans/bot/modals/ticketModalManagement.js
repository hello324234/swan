const ticketDropdown = require("../dropdowns/ticketsystem");

module.exports = {
  customID: "ticketModal_management",
  async execute(interaction) {
    return ticketDropdown.handleModal(interaction);
  },
};
