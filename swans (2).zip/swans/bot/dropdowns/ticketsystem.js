const {
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const Ticket = require('../utils/ticketSchema');

module.exports = {
  customID: 'ticketDropdown',
  
  async execute(interaction) {
    try {
      const selectedValue = interaction.values[0];

      // Show modal
      const modal = new ModalBuilder()
        .setCustomId(`ticketModal_${selectedValue}`)
        .setTitle('Create Support Ticket');

      // --- FIXED INPUTS ---
      const helpInput = new TextInputBuilder()
        .setCustomId('helpInput')
        .setLabel('Describe your issue')
        .setPlaceholder('Explain your problem here...')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true);

      const robloxInput = new TextInputBuilder()
        .setCustomId('robloxInput')
        .setLabel('Roblox Username')
        .setPlaceholder('Required')
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

      const row1 = new ActionRowBuilder().addComponents(helpInput);
      const row2 = new ActionRowBuilder().addComponents(robloxInput);

      modal.addComponents(row1, row2);

      await interaction.showModal(modal);

    } catch (error) {
      console.error('Error showing modal:', error);
    }
  },

  async handleModal(interaction) {
    try {
      await interaction.deferReply({ ephemeral: true });

      const ticketType = interaction.customId.split('_')[1];

      // --- FIXED INPUT NAMES ---
      const helpDescription = interaction.fields.getTextInputValue('helpInput');
      const robloxUsername = interaction.fields.getTextInputValue('robloxInput') || 'Not provided';

      const guild = interaction.guild;
      const user = interaction.user;

      const ticketConfig = {
        general: {
          role: '1449832635672301669',
          category: '1447342920687550665',
        },
        management: {
          role: '1449832635672301669',
          category: '1449818537735491834',
        },
      };

      const config = ticketConfig[ticketType];
      if (!config) {
        return interaction.editReply({
          content: 'Invalid ticket type selected.',
        });
      }

      const channel = await guild.channels.create({
        name: `${user.username}-${ticketType}`,
        type: ChannelType.GuildText,
        parent: config.category,
        permissionOverwrites: [
          {
            id: guild.roles.everyone.id,
            deny: [PermissionFlagsBits.ViewChannel],
          },
          {
            id: user.id,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
          },
          {
            id: config.role,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
          },
        ],
      });

      const ticketId = channel.id;

      const robloxLink =
        robloxUsername !== 'Not provided'
          ? `[${robloxUsername}](https://www.roblox.com/users/profile?username=${encodeURIComponent(robloxUsername)})`
          : 'Not provided';

      const embed = new EmbedBuilder()
        .setTitle('New Support Ticket')
        .setColor('#242429')
        .setDescription(
          `Thank you for reaching out. Please wait for support to assist you.`
        )
        .addFields(
          { name: 'Issue Description', value: helpDescription },
          { name: 'Roblox Info', value: robloxLink }
        )
        .setFooter({ text: `Ticket ID: ${ticketId}` })
        .setTimestamp();

      const claimButton = new ButtonBuilder()
        .setCustomId('claimTicket')
        .setLabel('Claim')
        .setStyle(ButtonStyle.Secondary);

      const closeButton = new ButtonBuilder()
        .setCustomId('closeTicket')
        .setLabel('Close')
        .setStyle(ButtonStyle.Danger);

      const actionRow = new ActionRowBuilder().addComponents(claimButton, closeButton);

      const ticketMessage = await channel.send({
        content: `<@${user.id}> | <@&${config.role}>`,
        embeds: [embed],
        components: [actionRow],
      });

      await Ticket.create({
        userId: user.id,
        username: user.username,
        channelId: channel.id,
        messageId: ticketMessage.id,
        helpDescription,
        robloxInfo: robloxUsername,
        status: 'open',
        createdAt: new Date(),
        claimedBy: null,
        claimStatus: 'unclaimed',
        closedBy: null,
        ticketId,
      });

      await interaction.editReply({
        content: `Your **${ticketType}** ticket has been created - <#${channel.id}>`,
      });

    } catch (error) {
      console.error('Error creating ticket:', error);
      await interaction.editReply({
        content: 'An error occurred while creating your ticket.',
      }).catch(() => {});
    }
  },
};
