const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('review')
        .setDescription('Leave a review for a developer')
        .addUserOption(option =>
            option.setName('developer')
                .setDescription('The developer you are reviewing')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('product')
                .setDescription('Product developed')
                .setRequired(true)
                .addChoices(
                    { name: 'liveries', value: 'liveries' },
                    { name: 'uniforms', value: 'uniforms' },
                    { name: 'Graphics', value: 'Graphics' },
                    { name: 'Discord', value: 'Discord' },
                    { name: 'Alting', value: 'Alting' },
                ))
        .addStringOption(option =>
            option.setName('review')
                .setDescription('Star rating of the service')
                .setRequired(true)
                .addChoices(
                    { name: '⭐', value: '1' },
                    { name: '⭐⭐', value: '2' },
                    { name: '⭐⭐⭐', value: '3' },
                    { name: '⭐⭐⭐⭐', value: '4' },
                    { name: '⭐⭐⭐⭐⭐', value: '5' },
                ))
        .addStringOption(option =>
            option.setName('feedback')
                .setDescription('Feedback about the service')
                .setRequired(true)),

    async execute(interaction) {
        try {
            // ✅ Defer FIRST (fixes InteractionNotReplied)
            await interaction.deferReply({ ephemeral: true });

            const requiredRoleId = '1447342838487453870';

            // Permission check
            if (!interaction.member.roles.cache.has(requiredRoleId)) {
                return interaction.editReply({
                    content: 'You do not have permission to use this command.',
                });
            }

            const developer = interaction.options.getUser('developer');
            const product = interaction.options.getString('product');
            const ratingInput = interaction.options.getString('review');
            const feedback = interaction.options.getString('feedback');

            const starMap = {
                "1": ' <:Star:1447363041044725760>'.repeat(1),
                "2": ' <:Star:1447363041044725760>'.repeat(2),
                "3": ' <:Star:1447363041044725760>'.repeat(3),
                "4": ' <:Star:1447363041044725760>'.repeat(4),
                "5": ' <:Star:1447363041044725760>'.repeat(5),
               
            };

            const review = starMap[ratingInput];

            const reviewChannel = await interaction.guild.channels.fetch('1447343047116460143');
            if (!reviewChannel) {
                return interaction.editReply({
                    content: 'Could not find the review channel.',
                });
            }

            const embed = new EmbedBuilder()
                .setColor('#242429')
                .setTitle('New Review')
                .setAuthor({
                    name: interaction.user.tag,
                    iconURL: interaction.user.displayAvatarURL(),
                })
                .addFields(
                    { name: 'Developer', value: `<@${developer.id}>`, inline: true },
                    { name: 'Product', value: product, inline: true },
                    { name: 'Rating', value: review, inline: true },
                    { name: 'Feedback', value: feedback },
                )
                .setImage(
                    'https://media.discordapp.net/attachments/1447379730352308306/1447387615652352080/image.png?format=webp&quality=lossless'
                );

            await reviewChannel.send({ embeds: [embed] });

            // ✅ Final response
            await interaction.editReply({
                content: 'Your review has been submitted successfully!',
            });

        } catch (err) {
            console.error('Error submitting review:', err);

            if (interaction.deferred || interaction.replied) {
                await interaction.editReply({
                    content: 'There was an error submitting the review. Please try again later.',
                });
            } else {
                await interaction.reply({
                    content: 'There was an error submitting the review. Please try again later.',
                    ephemeral: true,
                });
            }
        }
    }
};
