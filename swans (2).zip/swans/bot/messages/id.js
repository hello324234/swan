module.exports = {
  name: 'id',
  description: 'Get a user ID!',
  async execute(message, args) {
    // Get the first mentioned user, or fallback to the author
    const user = message.mentions.users.first() || message.author;

    const userId = user.id;

    // Send only the ID
    await message.reply(`${userId}`);
  },
};
