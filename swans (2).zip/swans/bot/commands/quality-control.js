const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('quality-control')
        .setDescription('Request quality control')
        .addAttachmentOption(option => 
            option.setName('image')
                .setDescription('Image to be reviewed')
                .setRequired(false)
        ),
        
    async execute(interaction) {
        const requiredRoleId = '1447342834939334698';

        
        if (!interaction.member.roles.cache.has(requiredRoleId)) {
            return interaction.reply({
                content: 'You do not have permission to use this command.',
                ephemeral: true,
            });
        }

 
        await interaction.deferReply({ ephemeral: true });

        const qualityControlRoleId = '1447342830229127230';

        const channel = await interaction.guild.channels.fetch('1449809966709080215'); 
        if (!channel) {
            return interaction.editReply({
                content: 'Could not find the promotion log channel.',
            });
        }

        const user = interaction.user; 
        const roleToPing = `<@&${qualityControlRoleId}>`;
        const userToPing = `<@${user.id}>`;
        const imageAttachment = interaction.options.getAttachment('image');

        const embed = new EmbedBuilder()
            .setTitle('Quality Control Request')
            .setColor('#242429')
            .setAuthor({
                name: interaction.user.tag,
                iconURL: interaction.user.displayAvatarURL(),
            })
            .setDescription(`${userToPing} has requested Quality Control`)
            .setImage(
                'https://media.discordapp.net/attachments/1447379730352308306/1447387615652352080/image.png'
            );

        const acceptButton = new ButtonBuilder()
            .setCustomId('accept')
            .setLabel('Accept')
            .setStyle(ButtonStyle.Success);

        const denyButton = new ButtonBuilder()
            .setCustomId('deny')
            .setLabel('Deny')
            .setStyle(ButtonStyle.Danger);

        const row = new ActionRowBuilder().addComponents(acceptButton, denyButton);

        try {
            const message = await channel.send({
                content: roleToPing,
                embeds: [embed],
                components: [row],
            });

            const thread = await message.startThread({
                name: 'Quality Control Feedback',
                reason: `Result on ${user.username}'s work.`,
                autoArchiveDuration: 60,
            });

            if (imageAttachment) {
                await thread.send({
                    content: `${userToPing} A thread has been created for you to discuss your work with quality assurance members.`,
                    files: [imageAttachment.url],
                });
            } else {
                await thread.send({
                    content: `${userToPing} A thread has been created for you to discuss your work with quality assurance members.`,
                });
            }

            await interaction.editReply({
                content: 'Quality control has been requested.',
            });

        } catch (error) {
            console.error('Error creating thread:', error);

            if (interaction.deferred || interaction.replied) {
                await interaction.editReply({
                    content: 'There was an error creating the quality control thread.',
                });
            }
        }
    },
};
