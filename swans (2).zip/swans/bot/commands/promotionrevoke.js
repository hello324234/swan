const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Promotion = require('../utils/promotionSchema');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('promotion-revoke')
    .setDescription('Void a promotion by its ID')
    .addStringOption(option =>
      option.setName('id')
        .setDescription('The promotion ID')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the revoke')
        .setRequired(true)
    ),

  async execute(interaction) {
    try {
      const promotionId = interaction.options.getString('id');
      const reason = interaction.options.getString('reason');
      const handler = interaction.user;

      const authorMember = await interaction.guild.members.fetch(handler.id);
      const requiredRole = '1447342830229127230';

      if (!authorMember.roles.cache.has(requiredRole)) {
        return interaction.reply({ content: 'You do not have **permission** to use this command.', flags: 64 });
      }

      const promotion = await Promotion.findOne({ promotionId });
      if (!promotion) {
        return interaction.reply({ content: 'Could not find a **promotion** with that ID.', flags: 64 });
      }

      if (promotion.userId === handler.id) {
        return interaction.reply({ content: 'You cannot **revoke** your promotion.', flags: 64 });
      }

      const promotionChannel = interaction.guild.channels.cache.get('1447343152280109086');
      if (promotionChannel) {
        const messages = await promotionChannel.messages.fetch({ limit: 100 });
        const message = messages.find(msg => msg.embeds.length > 0 && msg.embeds[0].footer?.text.includes(promotionId));

        if (message) {
          const embed = message.embeds[0];
          let newFooterText = embed.footer.text;
          if (!newFooterText.includes('• Revoked')) {
            newFooterText += ' • Revoked';
          }
          const updatedEmbed = EmbedBuilder.from(embed).setFooter({ text: newFooterText, iconURL: embed.footer.iconURL });
          await message.edit({ embeds: [updatedEmbed] });

          await message.reply({
            content: `Promotion for <@${promotion.userId}> has been revoked by <@${handler.id}>, reason; **${reason}**`
          });
        }
      }

      await Promotion.deleteOne({ promotionId });

      return interaction.reply({ content: `**Successfully** revoked <@${promotion.userId}>'s promotion.`, flags: 64 });

    } catch (error) {
      console.error(' Promotion Revoke command error:', error);

      const errorReply = {
        content: 'An **error** occurred, try again later.',
        flags: 64
      };

      try {
        if (interaction.deferred || interaction.replied) {
          await interaction.followUp(errorReply);
        } else {
          await interaction.reply(errorReply);
        }
      } catch (e) {
        console.error(' Promotion Revoke command error:', e);
      }
    }
  }
};