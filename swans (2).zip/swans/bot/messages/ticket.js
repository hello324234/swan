const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder
} = require("discord.js");

module.exports = {
  name: "tickets",
  cooldown: 5,
  async execute(message) {
    await message.delete();

    const requiredRoleId = "1447342829629346034"; // Role ID required to use this command
    if (!message.member.roles.cache.has(requiredRoleId)) return;

    const topBanner = new EmbedBuilder()
      .setColor("#242429")
      .setImage(
        "https://media.discordapp.net/attachments/1447379730352308306/1449815812746776576/DEPARTMENTS_16.png?ex=69419732&is=694045b2&hm=6ef54ff6e7359797ec497d12e4a6169fbce49f41e70a33f8259c626167e8bb43&=&format=webp&quality=lossless&width=902&height=346"
      );

    const mainEmbed = new EmbedBuilder()
      .setColor("#242429")
      .setTitle("Swans Lake Support System") 
      .setDescription(
        "Looking for assistance? You've come to the right place! Whether you have a question, concern, or need to report an issue, our support system is here to help. Select the appropriate ticket type below."
      )
      .addFields(
        {
          name: "<:person:1406711963823636510> **General Support**",
          value:
            "- Server Enquiries\n- Concerns\n- General Questions\n- Affiliations",
          inline: true
        },
        {
          name: "<:hammer:1406761849910853672> **Management Support**",
          value:
            "- Claiming Giveaways\n- Shop Purchases\n- Pack Claims\n- Reports / Appeals",
          inline: true
        }
      )
      .setImage(
        "https://media.discordapp.net/attachments/1447379730352308306/1449822512123875348/image.png?ex=69419d6f&is=69404bef&hm=69ac3dbe8ba71b4729957bbd4be19ace0b6b2b93dbf5074e2f0e9aacc25ca1f3&=&format=webp&quality=lossless&width=915&height=344"
      )
      .setFooter({ text: "All rights reserved, Swans Lake © 2025" });

    const dropdownMenu = new StringSelectMenuBuilder()
      .setCustomId("ticketDropdown")
      .setPlaceholder("Request assistance")
      .addOptions(
        {
          label: "General Support",
          value: "general"
        },
        {
          label: "Management Support",
          value: "management"
        }
      );

    const row = new ActionRowBuilder().addComponents(dropdownMenu);

    await message.channel.send({
      embeds: [topBanner, mainEmbed],
      components: [row]
    });
  }
};
